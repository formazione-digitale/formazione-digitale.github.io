ServerLab — File di supporto per il Laboratorio Script Bash
============================================================

ISTRUZIONI DI INSTALLAZIONE
----------------------------
1. Estrai questa cartella in C:\Users\tuonome\
   (da Git Bash corrisponde a ~/  ovvero la tua home directory)

2. Apri Git Bash

3. Spostati nella cartella:
      cd ~/lab_bash

4. Verifica il contenuto con:
      ls -la

5. Sei pronto. Segui le istruzioni nella guida online
   per eseguire gli script che richiedono file di dati.

STRUTTURA CARTELLE
------------------
lab_bash/
  dati/
    accessi.txt  <- ore di accesso per utente (stataccessi.sh)
  servizi/     <- stato dei servizi .status (contatore.sh)
  logs/        <- log accessi, errori e sistema (menu.sh, funzioni.sh)
  utenti/      <- profili utente fittizi .txt (menu.sh, funzioni.sh)
  report/      <- cartella di output popolata da funzioni.sh

NOTA: la cartella report/ e' vuota alla prima estrazione.
