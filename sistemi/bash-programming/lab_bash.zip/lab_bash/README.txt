ServerLab — File di supporto per il Laboratorio Script Bash
============================================================

ISTRUZIONI
----------
1. Estrai in C:\Users\tuonome\ (da Git Bash: ~/)
2. cd ~/lab_bash
3. bash nomescript.sh

STRUTTURA
---------
dati/accessi.txt  <- ore di accesso (stataccessi.sh, lab13)
logs/accessi.log  <- log accessi utenti (lab13)
logs/errori.log   <- log errori sistema (lab13)
logs/sistema.log  <- scritto da funzioni.sh
servizi/*.status  <- stato servizi (contatore.sh)
utenti/*.txt      <- profili utente (menu.sh, funzioni.sh)
report/           <- output di funzioni.sh (vuota inizialmente)
